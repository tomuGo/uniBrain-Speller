# coding:utf-8
# cython:language_level=3
import multiprocessing
import logging
import os
import sys
import threading

import serial
import struct
import time
from neuro_dancer.core import Encoder, Decoder, Constant, NeuroDanceQueue, ProcessMsg, Crc32, Heart

buf_length = 10000
# 每10s 发送时间同步
sync_timespan_seconds = 2
battery_seconds = 60


class NeuroDancerException(Exception):

    def __init__(self, msg):
         self.message = msg

    def __str__(self):
        return self.message


class NeuroDanceSerial:

    def __init__(self):
        self.reconnect = True
        self.serial = None

    def open_port(self, port):
        self.close()
        self.reconnect = True
        self.port = port
        self._serial_open()

    def _serial_open(self, max_try_time=60):
        connect = False
        try_time = 0
        while connect is False and try_time <= max_try_time and self.reconnect:
            try:
                self.serial = serial.Serial(xonxoff=True,
                                            baudrate=1382400,
                                            bytesize=8,
                                            parity=serial.PARITY_NONE,)
                self.serial.dtr = True
                self.serial.rts = False
                self.serial.port = self.port
                self.serial.write_timeout = 0
                self.serial.open()
                connect = self.serial.is_open
            except Exception as e:
                print("connect {0} error,try times{1},error:{2}".format(self.port, try_time, e))
                try_time = try_time + 1
                time.sleep(1)
        print("serial:{0} open success".format(self.port))
        return connect

    def write_whatever(self, data):
        try:
            self.serial.write(data)
        except Exception as e:
            print("write serial error:{0}".format(e))

    def write(self, data):
        if not self.is_open():
            return None
        try:
            self.serial.write(data)
        except Exception as e:
            print("write serial error:{0}".format(e))
            self._serial_open(max_try_time=60)

    def read_all(self):
        if not self.is_open():
            return None
        try:
            return self.serial.read_all()
        except Exception as e:
            print("read serial error:{0}".format(e))
            self._serial_open(max_try_time=60)

    def is_open(self):
        if self.serial is None:
            return False
        return self.serial.is_open

    def close(self):
        self.reconnect = False
        if self.serial is not None and self.serial.is_open:
            self.serial.close()


count_per_package_available = [40, 80, 100, 200]


class NeuroDancerProcess(multiprocessing.Process):

    __encoder = Encoder()
    __decoder = Decoder()
    __heart = Heart()
    __host_mac_bytes = []
    __host_mac = None
    __device_connect_status = False
    __device_connect_status_last_update_time = None

    def __init__(self, com, send_queue, recv_queue, host_mac_bytes=None):
        self.__host_mac_bytes = host_mac_bytes
        self.send_queue = send_queue
        self.recv_queue = recv_queue
        multiprocessing.Process.__init__(self)
        self.com = com
        print("pid:{0}".format(os.getpid()))

    def is_ready(self):
        return len(self.__host_mac_bytes) > 0

    def __heartbeat(self, nd_serial):
        print("sycn :{0}".format(time.time()))
        # send host mac to device
        self.__heart.heart(nd_serial, self.__host_mac_bytes)
        # 定时发一个设备查询指令，以此判断设备连接情况
        sn_search = self.__encoder.device_sn()
        nd_serial.write(sn_search)

    def run(self):
        print("process start")
        nd_serial = NeuroDanceSerial()
        nd_serial.open_port(self.com)
        print("child process pid:{0}".format(os.getpid()))
        nd_queue = NeuroDanceQueue()
        last_heartbeat_second = None
        while True:
            # heart
            now = time.time()
            if last_heartbeat_second is None or now - last_heartbeat_second > 10:
                self.__heartbeat(nd_serial)
                last_heartbeat_second = time.time()
            # consume cmd message
            close = self.__cmd_message_consume(nd_serial)
            if close:
                break
            # decode serial data
            if not nd_serial.is_open():
                continue
            data = nd_serial.read_all()
            if data and len(data) > 0:
                for b in data:
                    nd_queue.en_queue(b)
                res = self.__decoder.decode(nd_queue)
                for msg in res:
                    self.recv_queue.put(msg)

        nd_serial.close()
        self.send_queue.close()
        self.recv_queue.close()
        print("Neuro Dancer Process Closed")

    def send_cmd_from_send_queue(self):
        is_empty = self.send_queue.empty()
        if is_empty:
            return
        self.send_queue.get(block=False)

    # return closed
    def __cmd_message_consume(self, nd_serial):
        # is_empty = self.send_queue.empty()
        # if is_empty:
        #     return
        while not self.send_queue.empty():
            var = self.send_queue.get()
            print("cmd:{0}".format(var['key']))
            if var['key'] == ProcessMsg.close:
                return True
            self.send_cmd(nd_serial, var['key'], var['data'])
        return False

    # 具有value的包括：
    # 配对（mac地址），使能（每包多少点）
    def send_cmd(self, nd_serial, key, value):
        data = None
        if key == ProcessMsg.close:
            # pass关闭线程
            pass
        elif key == ProcessMsg.host_version_info:
            # 获取主机版本号的指令
            data = self.__encoder.host_version()
        elif key == ProcessMsg.host_sn_info:
            data = self.__encoder.host_device_sn()
        elif key == ProcessMsg.host_mac_bytes_info:
            data = self.__encoder.host_device_mac()
        elif key == ProcessMsg.device_version_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_version()
        elif key == ProcessMsg.device_mac_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_mac()
        elif key == ProcessMsg.device_sn_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_sn()
        elif key == ProcessMsg.device_battery_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_battery()
        elif key == ProcessMsg.ble_scan:
            clean = self.__encoder.device_scan_before()
            self.__cmd_write(nd_serial, clean)
            time.sleep(0.01)
            data = self.__encoder.device_scan()
        elif key == ProcessMsg.ble_pair:
            data = self.__encoder.device_pair(value)
        elif key == ProcessMsg.device_eeg_channels_config:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_eeg_channel_1000hz_config(value)
        elif key == ProcessMsg.device_eeg_channels_enable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_enable_eeg_channel()
        elif key == ProcessMsg.device_eeg_channels_disable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_disable_eeg_channel()
        elif key == ProcessMsg.device_eog_channels_config:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_eog_channel_1000hz()
        elif key == ProcessMsg.device_eog_channels_enable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_enable_eog_channel()
        elif key == ProcessMsg.device_eog_channels_disable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_disable_eog_channel()
        if data is not None:
            self.__cmd_write(nd_serial, data)

    def __cmd_write(self, nd_serial, cmd):
        nd_serial.write(cmd)

    def __recv(self, key, data):
        self.recv_queue.put({'key':key, 'data':data})

    def __device_connect_status_received(self, status):
        if status:
            self.__device_connect_status = True
            second_now = int(round(time.time()))
            self.__device_connect_status_last_update_time = second_now
        else:
            self.__device_connect_status = False

    # 23s 没数据，认为断连
    def is_device_connected(self):
        second_now = int(round(time.time()))
        if self.__device_connect_status_last_update_time is None:
            return False
        return self.__device_connect_status and second_now - self.__device_connect_status_last_update_time < 23


class NeuroDancer(threading.Thread):

    __nd_process = None
    _message_recv = multiprocessing.SimpleQueue()
    _message_send = multiprocessing.SimpleQueue()
    __closed = False

    def __init__(self, com, host_mac_bytes=None):
        threading.Thread.__init__(self)
        self.__nd_process = NeuroDancerProcess(com, self._message_send, self._message_recv, host_mac_bytes)
        self.__nd_process.start()

    def run(self) -> None:
        while not self.__closed:
            self.__consume_recv()
        print("NeuroDancer Closed")

    def __consume_recv(self):
        is_empty = self._message_recv.empty()
        if not is_empty:
            var = self._message_recv.get()
            key = var['key']
            data = var['data']
            if key == ProcessMsg.host_version_info:
                self.host_version_received(data)
            elif key == ProcessMsg.host_sn_info:
                self.host_sn_received(data)
            elif key == ProcessMsg.host_mac_bytes_info:
                out_str = ''
                for i in range(0, len(data)):
                    out_str = out_str + (hex(int(data[i]))).upper()[2:].zfill(2)
                self.host_mac_received(out_str)
            elif key == ProcessMsg.device_version_info:
                self.device_version_received(data)
            elif key == ProcessMsg.device_mac_info:
                self.device_mac_received(data)
            elif key == ProcessMsg.device_sn_info:
                self.device_sn_received(data)
            elif key == ProcessMsg.device_battery_info:
                self.device_battery_received(data)
            elif key == ProcessMsg.ble_scan:
                self.devices_received(data)
            elif key == ProcessMsg.ble_pair:
                pass
            elif key == ProcessMsg.device_eeg_channels_config_response:
                pass
            elif key == ProcessMsg.device_eeg_channels_data:
                self.eeg_received(data)
            elif key == ProcessMsg.device_eeg_channels_disable_response:
                pass
            elif key == ProcessMsg.device_eog_channels_config_response:
                pass
            elif key == ProcessMsg.device_eog_channels_enable_response:
                pass
            elif key == ProcessMsg.device_eog_channels_disable_response:
                pass
            elif key == ProcessMsg.device_eog_channels_data:
                pass
            elif key == ProcessMsg.decode_error:
                self.decode_error()
            elif key == ProcessMsg.crc_error:
                self.crc_error()
            elif key == ProcessMsg.cmd_error:
                self.cmd_error(data[0], data[1], data[2])

    def enable_channels(self, count_per_pkg):
        if count_per_pkg not in count_per_package_available:
            raise NeuroDancerException("count_per_pkg must in {0}".format(count_per_package_available))
        self.__message_send(ProcessMsg.device_eeg_channels_config, count_per_pkg)
        time.sleep(0.01)
        self.__message_send(ProcessMsg.device_eeg_channels_enable, None)

    def disable_channels(self):
        self.__message_send(ProcessMsg.device_eeg_channels_disable, None)

    def host_version_info(self):
        self.__message_send(ProcessMsg.host_version_info, None)

    def host_mac_info(self):
        self.__message_send(ProcessMsg.host_mac_bytes_info, None)

    def host_sn_info(self):
        self.__message_send(ProcessMsg.host_sn_info, None)

    def host_device_connect(self):
        self.__message_send(ProcessMsg.device_connect_status_info, None)

    # ---------------device info ----------------------
    def device_version_info(self):
        self.__message_send(ProcessMsg.device_version_info, None)

    def device_sn_info(self):
        self.__message_send(ProcessMsg.device_sn_info, None)

    def device_mac_info(self):
        self.__message_send(ProcessMsg.device_mac_info, None)

    def device_battery(self):
        self.__message_send(ProcessMsg.device_battery_info, None)

    def pair(self, mac):
        self.__message_send(ProcessMsg.ble_pair, mac)

    def device_scan(self):
        self.__message_send(ProcessMsg.ble_scan, None)

    def __message_send(self, key, value):
        self._message_send.put({'key': key, 'data': value})

    def close(self):
        self.__closed = True
        self.__message_send(ProcessMsg.close, None)
        self.__nd_process.join()

    def host_mac_received(self, host_mac):
        print("host mac:{0}".format(host_mac))

    def host_sn_received(self, host_sn):
        print("host sn:{0}".format(host_sn))

    def channel_received(self, data):
        print("channel_received")

    def host_version_received(self, host_version):
        print("host version:{0}".format(host_version))

    def device_mac_received(self, device_mac):
        print("device mac:{0}".format(device_mac))

    def device_sn_received(self, device_sn):
        pass

    def device_battery_received(self, battery):
        pass

    def device_version_received(self, device_version):
        pass

    def eeg_received(self, data):
        pass

    def devices_received(self, devices):
        pass

    def cmd_error(self, cmd, pm, code):
        print("cmd error:{0},pm:{1},code:{2}".format(cmd, pm, code))

    def crc_error(self):
        print("crc error")

    def decode_error(self):
        print("decode error")


class NeuroDancerDeviceInfo(threading.Thread):

    __encoder = Encoder()
    __decoder = Decoder()
    __heart = Heart()
    __host_mac_bytes = []
    __host_mac = None
    __device_connect_status = False
    __device_connect_status_last_update_time = None

    def __init__(self):
        threading.Thread.__init__(self)
        self._nd_queue = NeuroDanceQueue()
        self.__closed = False
        self.__serial_tool = NeuroDanceSerial()
        self.disable_channels()
        self.host_mac_info()
        self.lock = threading.Lock()
        self.__sync_run()

    def __sync_run(self):
        if self.__closed:
            if self.sync_task is not None:
                self.sync_task.cancel()
        else:
            self.sync_task = threading.Timer(sync_timespan_seconds, self.__time_sync, ())
            self.sync_task.start()

    def is_ready(self):
        return len(self.__host_mac_bytes) > 0

    def __time_sync(self):
        self.__sync_run()
        self.__heart.heart(self.__serial_tool, self.__host_mac_bytes)
        # 定时发一个设备查询指令，以此判断设备连接情况
        self.device_sn_info()

    def close(self):
        self.__closed = True
        self.__serial_tool.close()
        self.sync_task.cancel()
        print("Neuro Dancer Closed")

    def open(self, com):
        self.__serial_tool.open_port(com)

    def run(self):
        while not self.__closed:
            if not self.__serial_tool.is_open():
                continue
            with self.lock:
                data = self.__serial_tool.read_all()
                if data and len(data) > 0:
                    for b in data:
                        self._nd_queue.en_queue(b)
                    res = self.__decoder.decode(self._nd_queue)
                    for msg in res:
                        self.msg_call_back(msg)

        print("Neuro Dancer decoder Closed")

    def msg_call_back(self, msg):
        key = msg['key']
        data = msg['data']
        if key == ProcessMsg.host_version_info:
            self.host_version_received(data)
        elif key == ProcessMsg.host_sn_info:
            self.host_sn_received(data)
        elif key == ProcessMsg.host_mac_bytes_info:
            self.__host_mac_received(data)
        elif key == ProcessMsg.device_version_info:
            self.__device_connect_status_received(True)
            self.device_version_received(data)
        elif key == ProcessMsg.device_mac_info:
            self.__device_connect_status_received(True)
            self.device_mac_received(data)
        elif key == ProcessMsg.device_sn_info:
            self.__device_connect_status_received(True)
            self.device_sn_received(data)
        elif key == ProcessMsg.device_battery_info:
            self.__device_connect_status_received(True)
            self.device_battery_received(data)
        elif key == ProcessMsg.ble_scan:
            self.devices_received(data)
        elif key == ProcessMsg.ble_pair:
            pass
        elif key == ProcessMsg.device_eeg_channels_config_response:
            pass
        elif key == ProcessMsg.device_eeg_channels_data:
            self.__device_connect_status_received(True)
            self.eeg_received(data)
        elif key == ProcessMsg.device_eeg_channels_disable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_config_response:
            pass
        elif key == ProcessMsg.device_eog_channels_enable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_disable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_data:
            pass
        elif key == ProcessMsg.decode_error:
            self.decode_error()
        elif key == ProcessMsg.crc_error:
            self.crc_error()
        elif key == ProcessMsg.cmd_error:
            self.cmd_error(data[0], data[1], data[2])

    def disable_channels(self):
        data = self.__encoder.device_disable_eeg_channel()
        self.__serial_tool.write(data)

    # ------------ host_info----------------------

    def host_version_info(self):
        data = self.__encoder.host_version()
        self.__serial_tool.write(data)

    def host_mac_info(self):
        data = self.__encoder.host_device_mac()
        self.__serial_tool.write(data)

    def host_sn_info(self):
        data = self.__encoder.host_device_sn()
        self.__serial_tool.write(data)

    def host_device_connect(self):
        data = self.__encoder.host_device_connect()
        self.__serial_tool.write(data)

    # ---------------device info ----------------------
    def device_version_info(self):
        data = self.__encoder.device_version()
        self.__serial_tool.write(data)

    def device_sn_info(self):
        data = self.__encoder.device_sn()
        self.__serial_tool.write(data)

    def device_mac_info(self):
        data = self.__encoder.device_mac()
        self.__serial_tool.write(data)

    def device_battery(self):
        data = self.__encoder.device_battery()
        self.__serial_tool.write(data)

    def device_model_info(self):
        data = self.__encoder.device_model()
        self.__serial_tool.write(data)

    def pair(self, mac):
        data = self.__encoder.device_pair(mac)
        self.__serial_tool.write(data)

    def device_scan(self):
        before = self.__encoder.device_scan_before()
        self.__serial_tool.write(before)
        time.sleep(0.01)
        data = self.__encoder.device_scan()
        self.__serial_tool.write(data)

    def __device_connect_status_received(self, status):
        if status:
            self.__device_connect_status = True
            second_now = int(round(time.time()))
            self.__device_connect_status_last_update_time = second_now
        else:
            self.__device_connect_status = False

    # 23s 没数据，认为断连
    def is_device_connected(self):
        second_now = int(round(time.time()))
        if self.__device_connect_status_last_update_time is None:
            return False
        return self.__device_connect_status and second_now - self.__device_connect_status_last_update_time < 23

    def __device_msg_received(self):
        self.__device_connect_status = True
        self.__device_connect_status_last_update_time = time.time()

    def __host_mac_received(self, _host_mac_bytes):
        self.__host_mac_bytes = _host_mac_bytes
        out_str = ''
        for i in range(0, len(_host_mac_bytes)):
            out_str = out_str + (hex(int(_host_mac_bytes[i]))).upper()[2:].zfill(2)
        self.host_mac_received(out_str)

    def host_mac_received(self, host_mac):
        print("host mac:{0}".format(host_mac))

    def host_sn_received(self, host_sn):
        print("host sn:{0}".format(host_sn))

    def channel_received(self, data):
        print("channel_received")

    def host_version_received(self, host_version):
        print("host version:{0}".format(host_version))

    def device_mac_received(self, device_mac):
        print("device mac:{0}".format(device_mac))

    def device_sn_received(self, device_sn):
        pass

    def device_battery_received(self, battery):
        pass

    def device_version_received(self, device_version):
        pass

    def eeg_received(self, data):
        pass

    def devices_received(self, devices):
        pass

    def cmd_error(self, cmd, pm, code):
        print("cmd error:{0},pm:{1},code:{2}".format(cmd, pm, code))

    def crc_error(self):
        print("crc error")

    def decode_error(self):
        print("decode error")